/*
 * Decompiled from UC Berkeley's ucb.gui package.
 * @author P.N. Hilfinger
 */
package chess;

import javax.swing.JComponent;

public abstract class Widget {
    protected JComponent me;

    protected Widget() {
    }
}

